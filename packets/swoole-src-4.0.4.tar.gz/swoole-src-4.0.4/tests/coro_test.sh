#!/usr/bin/env bash
./start.sh swoole_client_coro/ swoole_coroutine/ swoole_coroutine_channel/ swoole_coroutine_util/ swoole_http_client_coro/ swoole_mysql_coro/ swoole_redis_coro/ swoole_socket_coro/
